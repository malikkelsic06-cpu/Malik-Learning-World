let xp=0;
function startMath(){
  document.getElementById('game').hidden=false;
  newQuestion();
  document.getElementById('game').scrollIntoView({behavior:'smooth'});
}
function newQuestion(){
  const a=Math.floor(Math.random()*10)+1,b=Math.floor(Math.random()*10)+1,answer=a+b;
  document.getElementById('question').textContent=`What is ${a} + ${b}?`;
  const choices=[answer,answer+1,Math.max(0,answer-1)].sort(()=>Math.random()-0.5);
  document.getElementById('answers').innerHTML='';
  choices.forEach(n=>{
    const btn=document.createElement('button'); btn.textContent=n;
    btn.onclick=()=>check(n,answer); document.getElementById('answers').appendChild(btn);
  });
}
function check(n,answer){
  const result=document.getElementById('result');
  if(n===answer){xp+=10;document.getElementById('xp').textContent=xp;result.textContent='🎉 Great job! +10 XP';setTimeout(newQuestion,700)}
  else result.textContent='💡 Try again!';
}
function comingSoon(){alert('🚀 This learning world is coming soon!');}
