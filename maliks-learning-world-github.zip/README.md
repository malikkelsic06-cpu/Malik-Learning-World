# Malik's Learning World 🌎🎮📚

A kid-friendly educational game website where learners can practice math, reading, science, art, and more.

## Run locally
Open `index.html` in a web browser.

## GitHub Pages
Upload the files to a GitHub repository, then enable GitHub Pages from the repository's Settings > Pages.

## Ads
The site includes an ad-ready placeholder. Add advertising only after selecting an ad provider whose policies and child-directed advertising requirements fit your site.
